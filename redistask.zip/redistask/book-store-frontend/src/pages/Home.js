import React, { useState, useEffect } from 'react';
import { getBooks, deleteBook } from '../services/api';
import BookList from '../components/BookList';

const Home = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    getBooks().then((response) => setBooks(response.data));
  }, []);

  const handleDelete = (id) => {
    deleteBook(id).then(() => {
      setBooks(books.filter((book) => book._id !== id));
    });
  };

  return (
    <div>
      <h1>Books</h1>
      <BookList books={books} onDelete={handleDelete} />
    </div>
  );
};

export default Home;
