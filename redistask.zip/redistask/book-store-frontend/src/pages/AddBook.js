import React from 'react';
import { addBook } from '../services/api';
import BookForm from '../components/BookForm';

const AddBook = () => {
  const handleAddBook = (bookData) => {
    addBook(bookData).then(() => {
      alert('Book added successfully!');
    });
  };

  return (
    <div>
      <h1>Add a New Book</h1>
      <BookForm onSubmit={handleAddBook} />
    </div>
  );
};

export default AddBook;
