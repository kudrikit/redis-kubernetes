import React, { useEffect, useState } from 'react';
import { getBooks } from '../services/api';
import BookList from '../components/BookList';

const PopularBooks = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    getBooks().then((response) => setBooks(response.data));
  }, []);

  return (
    <div>
      <h1>Popular Books</h1>
      <BookList books={books} />
    </div>
  );
};

export default PopularBooks;
