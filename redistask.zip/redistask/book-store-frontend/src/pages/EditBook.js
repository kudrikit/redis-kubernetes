import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getBook, updateBook } from '../services/api';
import BookForm from '../components/BookForm';

const EditBook = () => {
  const { id } = useParams(); // Получаем ID из параметров маршрута
  const navigate = useNavigate(); // Для перенаправления после сохранения
  const [book, setBook] = useState(null); // Хранение данных книги

  useEffect(() => {
    // Загружаем данные книги
    getBook(id).then((response) => setBook(response.data));
  }, [id]);

  const handleUpdate = (updatedBookData) => {
    updateBook(id, updatedBookData).then(() => {
      alert('Book updated successfully!');
      navigate('/'); // Возвращаемся на главную страницу
    });
  };

  if (!book) return <p>Loading...</p>;

  return (
    <div>
      <h1>Edit Book</h1>
      <BookForm initialData={book} onSubmit={handleUpdate} />
    </div>
  );
};

export default EditBook;
