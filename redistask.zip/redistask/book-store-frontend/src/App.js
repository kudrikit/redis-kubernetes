import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import AddBook from './pages/AddBook';
import PopularBooks from './pages/PopularBooks';
import BookDetails from './components/BookDetails';
import EditBook from './pages/EditBook';
import SessionManager from './components/SessionManager'; // Импортируем SessionManager

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/add-book" element={<AddBook />} />
        <Route path="/popular-books" element={<PopularBooks />} />
        <Route path="/books/:id" element={<BookDetails />} />
        <Route path="/edit-book/:id" element={<EditBook />} />
        <Route path="/sessions" element={<SessionManager />} /> {/* Новый маршрут */}
      </Routes>
    </Router>
  );
};

export default App;
