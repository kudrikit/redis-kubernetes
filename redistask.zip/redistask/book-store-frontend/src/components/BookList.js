import React from 'react';
import { Link } from 'react-router-dom';

const BookList = ({ books, onDelete }) => {
  return (
    <ul>
      {books.map((book) => (
        <li key={book._id}>
          <Link to={`/books/${book._id}`}>{book.title}</Link>
          <Link to={`/edit-book/${book._id}`}>
            <button>Edit</button>
          </Link>
          <button onClick={() => onDelete(book._id)}>Delete</button>
        </li>
      ))}
    </ul>
  );
};

export default BookList;
