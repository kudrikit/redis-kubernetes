import React, { useState } from 'react';
import axios from 'axios';

const SessionManager = () => {
  const [sessionId, setSessionId] = useState('');
  const [message, setMessage] = useState('');

  const handleCreateSession = async () => {
    try {
      const response = await axios.post('http://localhost:5000/sessions', {
        username: 'test_user',
        role: 'user',
      });
      setSessionId(response.data.sessionId);
      setMessage('Session created successfully!');
    } catch (error) {
      setMessage(error.response?.data?.message || 'Error creating session');
    }
  };

  const handleExtendSession = async () => {
    try {
      if (!sessionId) {
        setMessage('Please create a session first.');
        return;
      }
      await axios.put(`http://localhost:5000/sessions/${sessionId}`);
      setMessage('Session extended successfully!');
    } catch (error) {
      setMessage(error.response?.data?.message || 'Error extending session');
    }
  };

  const handleDeleteSession = async () => {
    try {
      if (!sessionId) {
        setMessage('Please create a session first.');
        return;
      }
      await axios.delete(`http://localhost:5000/sessions/${sessionId}`);
      setSessionId('');
      setMessage('Session deleted successfully!');
    } catch (error) {
      setMessage(error.response?.data?.message || 'Error deleting session');
    }
  };

  return (
    <div>
      <h1>Session Manager</h1>
      <p>Session ID: {sessionId || 'None'}</p>
      <button onClick={handleCreateSession}>Create Session</button>
      <button onClick={handleExtendSession} disabled={!sessionId}>
        Extend Session
      </button>
      <button onClick={handleDeleteSession} disabled={!sessionId}>
        Delete Session
      </button>
      {message && <p>{message}</p>}
    </div>
  );
};

export default SessionManager;
