import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/add-book">Add Book</Link></li>
        <li><Link to="/popular-books">Popular Books</Link></li>
        <li><Link to="/sessions">Session Manager</Link></li> {/* Новая ссылка */}
      </ul>
    </nav>
  );
};

export default Navbar;
